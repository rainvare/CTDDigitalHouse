package com.company;

public interface ImpuestoGravable {

    public Double gravarImpuesto(Double porcentaje);
}

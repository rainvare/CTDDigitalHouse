package com.company;
//Clase con interfaz
public class TituloLicenciatura extends Titulo implements Comparable {
    private String temaTesis;
    private String fechaDeEntregaDeTesis;
    private Integer cantidadTrabajosInvestigacion;

//Constructor

    public TituloLicenciatura(Persona persona, String fechaInicio, String fechaFinalizacion, Integer cantidadDeMaterias, Boolean selloMinisterio, Boolean selloInstituto, String temaTesis, String fechaDeEntregaDeTesis, Integer cantidadTrabajosInvestigacion) {
        super(persona, fechaInicio, fechaFinalizacion, cantidadDeMaterias, selloMinisterio, selloInstituto);
        this.temaTesis = temaTesis;
        this.fechaDeEntregaDeTesis = fechaDeEntregaDeTesis;
        this.cantidadTrabajosInvestigacion = cantidadTrabajosInvestigacion;
    }



//Métodos
@Override
public int compareTo(Object o) {
    TituloLicenciatura otroTituloLicenciatura = (TituloLicenciatura) o;
    if (this.cantidadTrabajosInvestigacion < otroTituloLicenciatura.cantidadTrabajosInvestigacion) return -1;
    else if (this.cantidadTrabajosInvestigacion > otroTituloLicenciatura.cantidadTrabajosInvestigacion) return 1;
    return 0;
}


}

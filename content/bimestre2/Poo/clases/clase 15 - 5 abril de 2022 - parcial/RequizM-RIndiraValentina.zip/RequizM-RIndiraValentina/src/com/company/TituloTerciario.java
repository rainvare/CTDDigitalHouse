package com.company;

public class TituloTerciario extends Titulo{
    private String validacion;

    //Constructor
    public TituloTerciario(Persona persona,String fechaInicio,String fechaFinalizacion,Integer cantidadDeMaterias,Boolean selloMinisterio,Boolean selloInstituto, String validacion){
        super(persona,fechaInicio,fechaFinalizacion,cantidadDeMaterias,selloMinisterio,selloInstituto);
        this.validacion= validacion;
    }

//Método


    public Boolean validoAnivelNacional(TituloTerciario tituloTerciario) {
      if(this.validacion=="nacional"){
          return true;
      }
      else{
          return false;
      }
    }
}

package com.company;

public class Main {

    public static void main(String[] args) {

        Persona persona1 = new Persona("Ana","Réquiz", 48505840, 24);
        Persona persona2= new Persona("Victor","Réquiz", 687685840, 33);


       TituloTerciario tituloTerciario = new TituloTerciario(persona1,"4/4/2017", "4/4/2021", 30, true,false,"Nacional");
        TituloLicenciatura tituloLicenciatura =new TituloLicenciatura(persona2,"12/3/2015","12/5/2022",60,true,true,"Desarrollo de Aplicaciones en Java formación inicial de programadores trainee en BA","5/4/2022",13);

        System.out.println(tituloTerciario.validoAnivelNacional(tituloTerciario));

    }


}

package com.company;
//clase abstracta
public abstract class Titulo{
private Persona persona;
private String fechaInicio;
private String fechaFinalizacion;
private Integer cantidadDeMaterias;
private Boolean selloMinisterio;
private Boolean selloInstituto;

//Constructor
public Titulo(Persona persona,String fechaInicio,String fechaFinalizacion,Integer cantidadDeMaterias,Boolean selloMinisterio,Boolean selloInstituto){
        this.persona=persona;
        this.fechaInicio=fechaInicio;
        this.fechaFinalizacion=fechaFinalizacion;
        this.selloMinisterio=selloMinisterio;
        this.selloInstituto=selloInstituto;
        this.cantidadDeMaterias=cantidadDeMaterias;
        }



//Método
public Boolean sePuedeEjercer(){
        if(this.selloInstituto&&this.selloMinisterio){
        return true;
        }
        else{
        return false;
        }
        }




}

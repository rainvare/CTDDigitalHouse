public interface Departamento {
    void getName();

}

# Practicando JSON

Utiliza este repositorio para practicar acceder a datos en formato JSON.

La practica se encuentra en ./js/index.js

let mensaje = 'hola mundo' // string (texto) 
mensaje = "chau mundo"

const nombre = "Santi"

var color = "azul"
var color = "amarillo"

const dni = 40100200 // number 

let haceCalor = true // camelCase 

console.log(typeof dni) // nos devuelve el tipo de dato almacenado
console.log(typeof mensaje) // nos devuelve el tipo de dato almacenado




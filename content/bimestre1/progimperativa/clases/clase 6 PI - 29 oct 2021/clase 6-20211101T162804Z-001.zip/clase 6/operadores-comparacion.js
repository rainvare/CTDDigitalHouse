let numeroBajo = 2;
let numeroGrande = 100;
console.log(numeroBajo);
console.log(numeroGrande);

console.log("");
// Comparaciones con símbolos " < " y " > "
let resultado1 = numeroBajo > numeroGrande;  // es false
let resultado2 = numeroBajo < numeroGrande;  // es true


// Comparaciones con símbolos " >= " y " <= "
resultado1 = numeroBajo >= numeroGrande; // es false
resultado2 = numeroBajo <= numeroGrande; // es true


// Comparaciones con símbolos " == " y " != "
resultado1 = numeroBajo == numeroGrande;    // es false
resultado2 = numeroBajo != numeroGrande;    // es true


// se puede abreviar la forma de operar matemáticamente
/* en vez de...

let total = 8;
total = total + 5;
console.log(total);
*/
// sea
let alto = 8;
alto *= 2;
console.log(alto);



let edad = 15;      // edad vale inicialmente 15
edad++;             // le suma 1 a edad
edad--;             // le resta 1 a edad
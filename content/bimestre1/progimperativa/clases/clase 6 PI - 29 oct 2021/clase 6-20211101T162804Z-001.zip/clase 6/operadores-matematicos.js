
// Los operadores matemáticos nos permiten hacer cálculos básicos

console.log(2+2) // suma
console.log(2-2) // resta
console.log(2*2) // multiplicar
console.log(2/2) // dividir

// ejemplo para el cálculo del IVA

let costoProducto = 100 * 1.21

-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: el_descubierto
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `empleado`
--

DROP TABLE IF EXISTS `empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleado` (
  `legajo` int NOT NULL AUTO_INCREMENT,
  `sucursal_numero` int NOT NULL,
  `apellido` varchar(25) NOT NULL,
  `nombre` varchar(25) NOT NULL,
  `domicilio` varchar(70) NOT NULL,
  `ciudad_id` int NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefono_movil` char(15) NOT NULL,
  `alta_contrato_laboral` date NOT NULL,
  PRIMARY KEY (`legajo`),
  KEY `fk_empleado_sucursal1_idx` (`sucursal_numero`),
  KEY `fk_empleado_ciudad1_idx` (`ciudad_id`),
  CONSTRAINT `fk_empleado_ciudad1` FOREIGN KEY (`ciudad_id`) REFERENCES `ciudad` (`id`),
  CONSTRAINT `fk_empleado_sucursal1` FOREIGN KEY (`sucursal_numero`) REFERENCES `sucursal` (`numero`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleado`
--

LOCK TABLES `empleado` WRITE;
/*!40000 ALTER TABLE `empleado` DISABLE KEYS */;
INSERT INTO `empleado` VALUES (1,10,'Rubén Arias','Ana Gabriela','Av. A. Fernandez',1,'anafer@gamil.com','+5491152020333','2020-11-30'),(2,1,'Miranda','Maria Agustina','P. A. Sarmiento 542',2,'maria.agustina@eldescubierto.com','+5491159001005','2021-06-02'),(3,12,'López','Mabel','Benjamin Harrison 710',17,'mabel440@eldescubierto.com','+573122611571','2021-05-11'),(4,5,'Macias','Nelson Adrián','James K. Polk 77',7,'nelson.adri@eldescubierto.com','+5493515701005','2019-01-25'),(5,4,'Manrique','Marcela Elisa','Rosalind Franklin 1233',6,'marcela.elisa@eldescubierto.com','+573105604570','2019-08-20'),(6,17,'Farina','Lizeth Daniela','Carlos Ibáñez piso 2 dpto. A',29,'lizeth.daniela@eldescubierto.com','+5491158108107','2017-12-28'),(7,17,'Chauchet Zamora','Diego Armando','Av. Rosa Parks 239',29,'diego.armando@eldescubierto.com','+5491158108107','2017-10-16'),(8,2,'Garcia','Nadia','Av. libertador 4250 este',3,'nadia2000@eldescubierto.com','+5493426457811','2017-06-06'),(9,4,'De Los Santos','Mario','Las palmeras 2388',6,'mario2045@eldescubierto.com','+5493416100500','2018-06-10'),(10,6,'Gutierrez','Valentina','Av. libertador 4750 este',10,'valentina1233@eldescubierto.com','+5493515770010','2018-05-29'),(11,5,'Tello Aguilera','Camilo Daniel','Saturnino Sarasa 122',7,'camilo.daniel@eldescubierto.com','+5491153015204','2020-08-03'),(12,18,'González Romero','Verónica Edith','Saturnino Sarasa 710',35,'veronica.edith@eldescubierto.com','+5493835100521','2017-01-11'),(13,22,'Martín','Guillermina Lucia','Simón Bolívar 155',1,'guillermina.lucia@eldescubierto.com','+5491155332223','2020-04-19'),(14,3,'Manrique Tello','Gabriel Eduardo','Luis Alberto Lacalle 300 piso 2 dpto. 10',5,'gabriel.eduardo@eldescubierto.com','+5493515685588','2020-11-27'),(15,14,'Morales','Miguel','John F. Kennedy 451',21,'miguel785@eldescubierto.com','+5491154050112','2017-05-19'),(16,1,'Aguirre','Maria Guadalupe','Manuel Eyzaguirre 1260',2,'maria.guadalupe@eldescubierto.com','+5492646747787','2021-09-24'),(17,9,'Martín Mercado','Dante Jose','Av. Sarmiento 702 oeste',14,'dante.jose@eldescubierto.com','+573105582411','2019-09-17'),(18,21,'Miranda','Zoe Valentina','José Mujica 540',47,'zoe.valentina@eldescubierto.com','+562239093455','2017-08-10'),(19,4,'Peña','Verónica','Las palmeras 200 casa 15',6,'veronica2010@eldescubierto.com','+5493416100500','2019-05-18'),(20,16,'Sosa Muñoz ','Cristian Nicolás','JOSÉ MARÍA CAMPO SERRANO 211',28,'cristian.nicolas@eldescubierto.com','+573105582234','2020-03-07'),(21,1,'Medina','Sofia Magdalena','Villa Lourdes Mza. D Casa 22',2,'sofia.magdalena@eldescubierto.com','+5492646747787','2018-02-14'),(22,2,'Torres León','Laura Martina','Barrio Neuquen mnblc. A piso 4 dpto. 2',3,'laura.martina@eldescubierto.com','+5493515904588','2020-08-03'),(23,13,'Barragan Aya','Antonella Vanesa','Av. Adriana Ocampo 455',20,'antonella.vanesa@eldescubierto.com','+5491155331001','2017-08-03'),(24,19,'Gómez Cuellar','Luis Angel','Córdoba 122 sur',38,'luis.angel@eldescubierto.com','+56921233122','2015-10-16'),(25,22,'Ontiveros Telle','John David','Calle Manuel Oribe 1100',1,'john.david@eldescubierto.com','+5491155332223','2021-09-02'),(26,6,'Acuña','Lucia Verónica','Av. Sarmiento 93 sur',10,'lucia.vero@eldescubierto.com','+5492616442221','2018-06-02'),(27,9,'Mercado','Angeles','Córdoba 1211 sur',14,'angeles@eldescubierto.com','+573105582411','2015-03-19'),(28,13,'González','Mariela Luciana','Esteban Echeverria 1145',20,'mariela.luciana@eldescubierto.com','+5491155331001','2016-04-05'),(29,5,'De Los Santos','Ernesto Segundo','Villa Nueva 300',7,'ernesto.segundo@eldescubierto.com','+5491153015204','2018-10-23'),(30,10,'Carranza','Leonardo Ariel','Av. G. Santos 1520',15,'leonardo.ariel@eldescubierto.com','+5492645123322','2020-03-04'),(31,3,'Cabrera Peña','Marcelo','Barrio Los Andes mnblc. B piso 2 dpto. C',5,'marcelo50@eldescubierto.com','+5492645665002','2019-05-09'),(32,8,'Pérez Tello','Virginia','Av. Rosalind Franklin 600',12,'virginia41@eldescubierto.com','+56224733622','2016-10-15'),(33,8,'Beltran Figueroa','Maria celeste','San Luis 1300 este',12,'maria.celeste@eldescubierto.com','+5492645661478','2020-08-01'),(34,15,'Naranjo','Adriana','John Adam 544 este',24,'adriana1103@eldescubierto.com','+5493426112020','2016-02-17'),(35,18,'Ramirez Muñoz ','Lucía Romina','Las palmeras 200 casa 154',35,'lucia.romina@eldescubierto.com','+5493835100521','2018-09-24'),(36,14,'Russo','Luís Alberto','George Washington 1277',21,'luis.alberto@eldescubierto.com','+5491154050112','2018-06-25'),(37,11,'Castillo','Guillermo','George Washington 211',16,'guillermo@eldescubierto.com','+5493816123004','2015-09-29'),(38,20,'Garcia Enrique','María Carina','Villa Angelica mnblc. B piso 2 dpto. 4',45,'maria.carina@eldescubierto.com','+5493816748870','2019-09-28'),(39,10,'Valencia Rojas','Brenda Carolina','Esteban Echeverria 3547',15,'brenda.carolina@eldescubierto.com','+5492645123322','2016-04-21'),(40,15,'Miranda Tello','Luís Enrique','Callejón Libertad 1410',24,'luis.enrique@eldescubierto.com','+5493426112020','2017-11-27'),(41,12,'Camacho Olave','Yesica melina','Calle Tucumán 547',17,'yesica.melina@eldescubierto.com','+573122611571','2019-11-29'),(42,19,'Romero Alonso','Mariela Lorena','Álvaro Uribe 5100',38,'mariela.lorena@eldescubierto.com','+56921233122','2018-11-14'),(43,21,'Colonia Díaz','Carla Andrea','Av. Sarmiento 92 oeste',47,'carla.andrea@eldescubierto.com','+562239093455','2015-05-04'),(44,3,'Roma','Miguel Angel','9 de Julio 3300',5,'miguel.angel@eldescubierto.com','+5493515685588','2015-07-21'),(45,7,'Bruno Maroni','Andres','V. Barco Vargas 999',12,'andres@eldescubierto.com','+5499416441010','2021-06-25'),(46,11,'Torres','Juan Carlos','Villa Angelica mnblc. F piso 2 dpto. 3',16,'juan.carlos@eldescubierto.com','+5493816123004','2016-06-08'),(47,20,'Mercado','Pedro','Libertad 3200',45,'pedro6411@eldescubierto.com','+5493816748870','2017-08-19'),(48,7,'Alaníz','Pablo Ariel','Ángela Camacho 566',12,'pablo.ariel@eldescubierto.com','+562239092001','2020-05-14'),(49,16,'Redondo','Angel','Ángela Camacho 122',28,'angel445@eldescubierto.com','+573105582234','2015-12-29'),(50,2,'Aguilera Rivarola','Lucio Enrique','Av. Sarmiento 4122',3,'lucio.enrique@eldescubierto.com','+5493426457811','2021-06-25');
/*!40000 ALTER TABLE `empleado` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-17 19:48:25

-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: el_descubierto
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ciudad`
--

DROP TABLE IF EXISTS `ciudad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ciudad` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `codigo_postal` char(10) NOT NULL,
  `pais_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ciudad_pais1_idx` (`pais_id`),
  CONSTRAINT `fk_ciudad_pais1` FOREIGN KEY (`pais_id`) REFERENCES `pais` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ciudad`
--

LOCK TABLES `ciudad` WRITE;
/*!40000 ALTER TABLE `ciudad` DISABLE KEYS */;
INSERT INTO `ciudad` VALUES (1,'Santiago - Santiago	',' 8320000	',4),(2,'Villa Krause - San Juan','5425',1),(3,'Monroe - Buenos Aires','2743',1),(4,'Las Heras - Mendoza','5539',1),(5,'Valle de San Juan - Tolima','733020',5),(6,'Las Condes - Santiago','7550000',4),(7,'Rivadavia - San Juan','5400',1),(8,'Santander - Concepción','681511',5),(9,'Abasto - Buenos Aires','1903',1),(10,'San Miguel - Tucumán','4105',1),(11,'São Pedro da Aldeia - Rio de Janeiro','28940',3),(12,'La Rioja - La Rioja','5300',1),(13,'Santa Lucía - Canelones','16306',19),(14,'Pilar - Buenos Aires','1629',1),(15,'Chepes - La Rioja','5470',1),(16,'Lujan de Cuyo - Mendoza','5507',1),(17,'Viña del Mar - Valparaíso','2520000',4),(18,'Villa Don Bosco - Santa Fé','3000',1),(19,'9 de Julio - San Juan','5417',1),(20,'Córdoba - Córdoba','5000',1),(21,'San Justo - Buenos Aires','1754',1),(22,'San Luis - San Luis','5700',1),(23,'Isidro Casanova - Buenos Aires','1765',1),(24,'San Luis - Tolima','733001',5),(25,'Punta Carretas - Montevideo','11300',19),(26,'Salamina - Caldas','172001',5),(27,'Toledo - Antioquia','052050',5),(28,'Alsina - Buenos Aires','2938',1),(29,'San Bernardo del Viento - Córdoba','231501',5),(30,'Montevideo - Montevideo','11000',19),(31,'Capilla del Monte - Córdoba','5118',1),(32,'San Rafael - Mendoza','5600',1),(33,'Cabo Frio - Rio de Janeiro','28905',3),(34,'Medellín - Antioquia','050022',5),(35,'Ciudad de la Costa - Canelones','15005',19),(36,'San Jorge - Buenos Aires','7404',1),(37,'Concón - Valparaíso','2510000',4),(38,'Chacabuco - Catamarca','4700',1),(39,'Rawson - Chubut','9103',1),(40,'Puerto Madryn - Chubut','9120',1),(41,'Cosquin - Córdoba','5166',1),(42,'Salta - Salta','4400',1),(43,'Tigre - Buenos Aires','1648',1),(44,'Bogotá - Bogotá','118942',5),(45,'Rosario - Santa Fé','2000',1),(46,'Puerto la Plata - Buenos Aires','1925',1),(47,'Independencia - Santiago','8380000',4),(48,'San Fernando - Buenos Aires','1646',1),(49,'Villa Mercedes - San Luis','5730',1),(50,'Arauquita -  Arauca','816010',5);
/*!40000 ALTER TABLE `ciudad` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-17 19:48:25

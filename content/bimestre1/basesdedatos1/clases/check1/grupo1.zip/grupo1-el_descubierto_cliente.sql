-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: el_descubierto
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `id` int NOT NULL AUTO_INCREMENT,
  `apellido` varchar(25) NOT NULL,
  `nombre` varchar(25) NOT NULL,
  `domicilio` varchar(70) NOT NULL,
  `ciudad_id` int NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefono_movil` char(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cliente_ciudad1_idx` (`ciudad_id`),
  CONSTRAINT `fk_cliente_ciudad1` FOREIGN KEY (`ciudad_id`) REFERENCES `ciudad` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,'Medina','Juan Luis','Av España 1477 sur',2,'medina@gamil.com','+5492645887741'),(2,'Manrique','Maria Laura','San Martin 325 oeste',2,'manrique@gmail.com','+5492645814545'),(3,'Acuña Ruiz','David','Juan Antonio Lavalleja piso 4 dpto. 13',12,'david@hotmail.com','+5499416441020'),(4,'Alaníz','Mario Rubén','Juan Antonio Lavalleja piso 2 dpto. 11',35,'mario.ruben@gmail.com','+59824157067'),(5,'Torres','Camilo','25 De Mayo 533',2,'camilo@hotmail.com','+5492645881234'),(6,'Martinez Páez','Patricia Liliana','25 de Mayo 522',21,'patricia.liliana@gmail.com','+5491153013300'),(7,'Tello','María Virginia','Villa Lourdes Mza. H Casa 10',27,'maria.virginia@hotmail.com','+562239109080'),(8,'Mercado','Joel','Benjamin Harrison 984',17,'joel@hotmail.com','+5491155110014'),(9,'Acuña','Marian','Calle John F. Kennedy 100',10,'marian@gmail.com','+5493815201055'),(10,'Castro','Nicole','Calle 5 y Santa Rosa 457',38,'nicole@hotmail.com','+5492646334001'),(11,'Mercado Alaníz','Paulina Estela','Córdoba 1254 sur',16,'paulina.estela@hotmail.com','+5492616120045'),(12,'Farina','Daniel Fernando','Av. Daniela Santos 1550',38,'daniel.fernando@hotmail.com','+5492664551002'),(13,'Ferreyra','Carlos Martín','George Washington 245',21,'carlos.martin@hotmail.com','+5491153456987'),(14,'Cabrera','Ignacio Andrés','Calle 13 Dpto. 22',24,'ignacio.andres@hotmail.com','+573105604100'),(15,'Gómez Arguello','Armando Joel','Esteban Echeverria 1100',45,'armando.joel@hotmail.com','+5493416106060'),(16,'Salcedo','Sonia Estefanía','John F. Kennedy 240',47,'sonia.estefania@live.com','+569984904451'),(17,'Manentti','Abraham David','Libertad 3250',2,'abraham.david@hotmail.com','+5492645887744'),(18,'Gómez','Juan David','Ángela Camacho 544',5,'juan.david@live.com','+573106415577'),(19,'Suárez López','Maria Luciana','Av. Rosa Parks 2330',3,'maria.luciana@gmail.com','+5491155161247'),(20,'Gonzalez Pérez','Martina','Saturnino Sarasa 756',7,'martina@hotmail.com','+5492646220012'),(21,'Beltran','Ariadna Lucia','Álvaro Uribe 544',38,'ariadna.lucia@hotmail.com','+5492665457710'),(22,'Garcia','Catalina Denise','Villa Angelica mnblc. G piso 5 dpto. 3',29,'catalina.denise@hotmail.com','+5499416123123'),(23,'López Beltran','Daniela','Av. Sarmiento 952 oeste',14,'daniela@gmail.com','+5491152004577'),(24,'Vargas Ariza','Ana Belen','Simón Bolívar 1255',35,'ana.belen@gmail.com','+59824224578'),(25,'Figueroa Martínez','Maria Alejandra','Manuel Eyzaguirre 1200',20,'maria.alejandra@gmail.com','+5491151234471'),(26,'Puerta Castro','Lorena Sofía','P. A. Sarmiento 122',23,'lorena.sofia@hotmail.com','+5491159088900'),(27,'Pérez Gómez','Pablo Ariel','9 de Julio 300 este',6,'pablo.ariel@hotmail.com','+56921000145'),(28,'Gutierrez Díaz','Victoria Belen','Las palmeras 200 casa 10',25,'victoria.belen@live.com','+573105001255'),(29,'Aguirre','David Antonio','Villa Don Tomás Mza. A Casa 6',17,'david.antonio@gmail.com','+5491155062278'),(30,'Gonzalez','Virginia','Av. Emmeline Pankhurst 3410',12,'virginia@yahoo.com','+5499415662580'),(31,'Palermo','Serena Martina','Manuel Blanco Encalada 1455',10,'serena.martina@hotmail.com','+5493815662312'),(32,'Peña','Carla Trinidad','Barrio Los Andes mnblc. A piso 2 dpto. B',29,'carla.trinidad@yahoo.com','+5499416445500'),(33,'Mercado','Mariana Edith','Barrio Neuquen mnblc. B piso 3 dpto. 5',41,'mariana.edith@hotmail.com','+5493515998070'),(34,'Salcedo','Zoe','John Adam 5573 este',20,'zoe@hotmail.com','+5491151233215'),(35,'Cantoni Castro','Patricia Abigaíl','Benjamin Harrison 9822',29,'patricia.abi@gmail.com','+5531521037054'),(36,'Olave Torres','Santiago Alberto','Carlos Ibáñez piso 3 dpto. 13',16,'santiago.alberto@gmail.com','+5492616445500'),(37,'Figueroa Martín','Simon Juan','Luis Alberto Lacalle 300 piso 6 dpto. 13',1,'simon.juan@gmail.com','+56221233681'),(38,'Vargas Gonzalez','Ricardo Emanuel','Ramón Freire Serrano 4500',38,'ricardo.emanuel@gmail.com','+5499416566806'),(39,'Vasquez Saiz','Juan David','Villa Don Tomás Mza. C Casa 26',39,'juan.david@live.com','+5492805448024'),(40,'Espinel','Damián Alejandro','Ada Lovelace piso 2 dpto. 10',14,'dami.alejandro@gmail.com','+5491155004711'),(41,'Ontiveros','Omar','Simón Bolívar 4582',28,'omar@hotmail.com','+5491159875587'),(42,'Díaz Ferreyra','Lucia','Av. libertador 3578 este',47,'lucia@hotmail.com','+569984850530'),(43,'Cabrera','Tamara','Av. almirante brown 1255',41,'tamara@hotmail.com','+5493515991155'),(44,'Torres Peña','Mario Manuel','Las palmas 4511 sur',20,'mar2021x@gmail.com','+5491151231414'),(45,'Gonzalez Gonzalez ','Ariel','Buenos Aires 300',12,'arielgonz@yahoo.com','+5499415655122');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-17 19:48:22

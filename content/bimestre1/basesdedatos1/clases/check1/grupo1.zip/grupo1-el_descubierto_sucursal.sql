-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: el_descubierto
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sucursal`
--

DROP TABLE IF EXISTS `sucursal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sucursal` (
  `numero` int NOT NULL AUTO_INCREMENT,
  `Ciudad_id` int NOT NULL,
  `domicilio` varchar(70) NOT NULL,
  `telefono_fijo` char(15) NOT NULL,
  PRIMARY KEY (`numero`),
  KEY `fk_Sucursales_Ciudad1_idx` (`Ciudad_id`),
  CONSTRAINT `fk_Sucursales_Ciudad1` FOREIGN KEY (`Ciudad_id`) REFERENCES `ciudad` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sucursal`
--

LOCK TABLES `sucursal` WRITE;
/*!40000 ALTER TABLE `sucursal` DISABLE KEYS */;
INSERT INTO `sucursal` VALUES (1,2,'25 De Mayo 358','+5492645883344'),(2,3,'Av. Rosa Parks 1245','+5491155160011'),(3,5,'Ángela Camacho 587','+573106410045'),(4,6,'9 de Julio 310 este','+56921001040'),(5,7,'Saturnino Sarasa 573','+5492646221200'),(6,10,'Calle John F. Kennedy 180','+5493815205047'),(7,12,'Juan Antonio Lavalleja 3445','+5499416442010'),(8,12,'Av. Emmeline Pankhurst 6744','+5499415664040'),(9,14,'George Washington 5400','+5491154051010'),(10,15,'Ramón Freire Serrano 7410','+5499416561578'),(11,16,'Córdoba 5754 sur','+5492616121545'),(12,17,'Ángela Camacho 274','+562239095065'),(13,20,'Luis Alberto Lacalle 4577','+5493515684747'),(14,21,'25 de Mayo 5220','+5491153017700'),(15,24,'Av A. Fernandez 1500','+573105607866'),(16,28,'Simón Bolívar 482','+5491159871325'),(17,29,'James K. Polk 717','+5493515701257'),(18,35,'Juan Antonio Lavalleja 740','+59824150000'),(19,38,'Las palmeras 1443','+5493835100012'),(20,45,'Las palmeras 400','+5493416100504'),(21,47,'John F. Kennedy 689','+569984908874'),(22,1,'Manuel Eyzaguirre 1230','+5491151115570');
/*!40000 ALTER TABLE `sucursal` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-17 19:48:23

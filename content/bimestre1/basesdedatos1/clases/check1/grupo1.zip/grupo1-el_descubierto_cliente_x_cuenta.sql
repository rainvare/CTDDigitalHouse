-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: el_descubierto
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cliente_x_cuenta`
--

DROP TABLE IF EXISTS `cliente_x_cuenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente_x_cuenta` (
  `cliente_id` int NOT NULL,
  `cuenta_numero` int NOT NULL,
  PRIMARY KEY (`cliente_id`,`cuenta_numero`),
  KEY `fk_cliente_has_cuenta_cuenta1_idx` (`cuenta_numero`),
  KEY `fk_cliente_has_cuenta_cliente1_idx` (`cliente_id`),
  CONSTRAINT `fk_cliente_has_cuenta_cliente1` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`),
  CONSTRAINT `fk_cliente_has_cuenta_cuenta1` FOREIGN KEY (`cuenta_numero`) REFERENCES `cuenta` (`numero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente_x_cuenta`
--

LOCK TABLES `cliente_x_cuenta` WRITE;
/*!40000 ALTER TABLE `cliente_x_cuenta` DISABLE KEYS */;
INSERT INTO `cliente_x_cuenta` VALUES (1,10501),(2,10502),(16,10503),(5,10504),(15,10505),(4,10506),(6,10507),(13,10507),(30,10508),(3,10509),(11,10510),(18,10511),(18,10512),(20,10513),(23,10514),(40,10514),(30,10515),(19,10516),(41,10517),(29,10518),(5,10519),(17,10519),(14,10520),(18,10521),(25,10522),(23,10523),(38,10524),(15,10525),(14,10526),(42,10527),(36,10528),(20,10529),(9,10530),(34,10531),(10,10532),(24,10533),(30,10534),(5,10535),(40,10536),(27,10537),(37,10538),(35,10539),(3,10540),(27,10541),(30,10542),(41,10543),(22,10544),(31,10545),(15,10546),(24,10547),(40,10548),(12,10549),(8,10550),(32,10551),(36,10552),(20,10553),(20,10554),(37,10555),(21,10556),(15,10557),(16,10558),(20,10559),(20,10560),(4,10561);
/*!40000 ALTER TABLE `cliente_x_cuenta` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-17 19:48:24

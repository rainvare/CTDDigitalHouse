package com.dh.student;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiStudentApplicationTests {

    @Test
    void contextLoads() {
    }

}

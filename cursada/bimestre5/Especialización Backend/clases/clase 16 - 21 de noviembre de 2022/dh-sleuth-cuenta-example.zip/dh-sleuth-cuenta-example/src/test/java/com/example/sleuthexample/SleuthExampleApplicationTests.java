package com.example.sleuthexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SleuthExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}

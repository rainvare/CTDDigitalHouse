package com.dh.caja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CajaApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.avaliacao_movieservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvaliacaoMovieServiceApplicationTests {

	@Test
	void contextLoads () {
	}

}

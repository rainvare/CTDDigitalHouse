package com.company;

public class OfertaAcademicaException extends Exception {

    public OfertaAcademicaException(String message) {
        super(message);
    }
}

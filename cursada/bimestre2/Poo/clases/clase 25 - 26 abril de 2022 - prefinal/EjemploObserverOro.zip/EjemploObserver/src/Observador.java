

public interface Observador {

    public String actualizar();
}

package com.company;

public class EquipoException extends Exception {

    public EquipoException(String message) {
        super(message);
    }
}

public class Programa {
    public static void main (String [] args){

        Auto vb = new Auto(40);
        vb.acelerar();
        vb.contacto();
        vb.acelerar();
        vb.acelerar();
        vb.acelerar();
        vb.acelerar();
        vb.acelerar();
        vb.acelerar();
        vb.acelerar();
        vb.frenar();
        vb.frenar();
        vb.frenar();
        vb.frenar();    }

}

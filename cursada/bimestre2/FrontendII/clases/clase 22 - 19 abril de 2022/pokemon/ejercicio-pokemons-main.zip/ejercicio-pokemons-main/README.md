# Pokemons! <img src="https://image.flaticon.com/icons/png/512/287/287221.png" width='25px'>

Esta actividad, consiste en utilizar barras de progreso para indicar las distintas habilidades de cada pokemon. Para ello, partiendo de un listado de pokemons, deberás manipular cada una de las cards creadas para mostrar la imagen del pokemon y, además, poder rellenar cada una de las barras de habilidades con la cantidad que corresponde a cada habilidad.

Además, segun el % de cada habilidad, la barra deberá ser de color rojo, amarilla o verde.

Una vez realizada la actividad, deberás ver el siguiente resultado final:

<img src="./assets/pokemon-finish.png" width='90%'>

Atrapalos ya! <img src='https://image.flaticon.com/icons/png/512/528/528098.png' width="25px"> <img src='https://image.flaticon.com/icons/png/512/189/189001.png' width="25px"><img src='https://image.flaticon.com/icons/png/512/188/188993.png' width="25px">


create table IF NOT EXISTS estudiantes(id BIGINT,nombre varchar(255),apellido varchar (255));
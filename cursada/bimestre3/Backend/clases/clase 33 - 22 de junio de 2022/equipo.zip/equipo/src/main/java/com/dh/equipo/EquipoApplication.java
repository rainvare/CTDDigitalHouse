package com.dh.equipo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EquipoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EquipoApplication.class, args);
	}

}

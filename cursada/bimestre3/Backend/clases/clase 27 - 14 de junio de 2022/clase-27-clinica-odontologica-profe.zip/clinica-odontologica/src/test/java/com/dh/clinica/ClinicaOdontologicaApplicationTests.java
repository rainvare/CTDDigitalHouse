package com.dh.clinica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaOdontologicaApplicationTests {

    @Test
    void contextLoads() {
    }

}

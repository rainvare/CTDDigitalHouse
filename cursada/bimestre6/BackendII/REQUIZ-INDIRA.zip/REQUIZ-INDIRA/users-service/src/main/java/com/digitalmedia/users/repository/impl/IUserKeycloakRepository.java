package com.digitalmedia.users.repository.impl;

public interface IUserKeycloakRepository {
}

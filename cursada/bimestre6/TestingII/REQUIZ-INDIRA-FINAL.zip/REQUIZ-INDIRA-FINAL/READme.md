## Final de Testing II - CTD


### Orden de ejecución de los Test en front:
- -TestRegister
- TestOpenAccount
- TestOverView
- TestAccountActivity
- TestTransferFunds

## Test de Back:
error 401 en testOpenNewAccountURL

### Reportes no incluidos
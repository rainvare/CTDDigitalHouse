package com.dh.testingii;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestingIiApplication {

    public static void main(String[] args) {
        SpringApplication.run(TestingIiApplication.class, args);
    }

}

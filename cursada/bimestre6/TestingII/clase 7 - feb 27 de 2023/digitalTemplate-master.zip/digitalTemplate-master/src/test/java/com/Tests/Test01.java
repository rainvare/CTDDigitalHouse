package com.Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Test01 {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}

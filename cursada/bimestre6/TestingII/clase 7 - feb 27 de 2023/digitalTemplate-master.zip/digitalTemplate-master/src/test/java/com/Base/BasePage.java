package com.Base;

public class BasePage {

}

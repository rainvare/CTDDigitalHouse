package com.dh.MDT;

import com.dh.MDT.Pages.BasePage;
import com.dh.MDT.Pages.LoginPage;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class MdtApplicationTests {

    WebDriver driver;
    BasePage home;
    LoginPage login;

    @BeforeAll
    public void setup() {

        System.setProperty("webdriver.edge.driver", "src/main/resources/msedgedriver.exe");
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("http://testing.ctd.academy/");
        home = new BasePage(driver);
        home.clickLogin();
    }

    @Test
    public void testLogin() {
        login = new LoginPage(driver);
        login.enterEmail("equipo9@digitalhouse.com");
        login.enterPassword("asd123");
        login.doClick();
        String result = login.checkMessage();
        assertTrue(result.contains("Sus credenciales son inválidas. Por favor, vuelva a intentarlo"));

        System.out.println("Resultado obtenido: " + result);
    }

    @AfterAll
    public void exit() {

        driver.quit();
    }
}

package com.dh.MDT;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.dh.MDT.Pages.BasePage;
import com.dh.MDT.Pages.LoginPage;
import com.dh.MDT.Pages.RegisterPage;
import com.extentReports.ExtentFactory;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class MdtApplicationTests {

    WebDriver driver;
    BasePage home;
    LoginPage login;
    RegisterPage register;
    static ExtentSparkReporter spark = new ExtentSparkReporter("./target/REPORTES.html");
    static ExtentReports extent;
    ExtentTest test;

    @BeforeAll
    public void setup() {
        System.setProperty("webdriver.edge.driver", "src/main/resources/msedgedriver.exe");
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("http://testing.ctd.academy/");
        extent = ExtentFactory.getInstance();
        extent.attachReporter(spark);
    }

    @Test
    @Tag("Login")
    @Tag("smoke")
    public void testLogin() {
        test = extent.createTest("Test Login Fallido");
        test.log(Status.INFO, "Inicia el Test");
        home = new BasePage(driver);

        home.clickLogin();
        test.log(Status.PASS, "Ingreso al Login");

        login = new LoginPage(driver);
        login.enterEmail("equipo9@digitalhouse.com");
        test.log(Status.PASS, "Ingreso mail");

        login.enterPassword("asd123");
        test.log(Status.PASS, "Ingreso contraseña");

        login.doClick();
        test.log(Status.PASS, "Click en boton Ingresar");

        String result = login.checkMessage();
        assertTrue(result.contains("Sus credenciales son inválidas. Por favor, vuelva a intentarlo"));
        test.log(Status.PASS, "Verifico mensaje de error");

        System.out.println("Resultado obtenido: " + result);
    }

    @Test
    @Tag("Registros")
    @Tag("Regresion")
    public void testRegister() {
        home = new BasePage(driver);
        home.clickRegister();
        register = new RegisterPage(driver);
        register.enterName("John");
        register.enterLastname("Smith");
        register.enterEmail("johnsmith1@gmail.com");
        register.enterPassword("asd123");
        register.confirmPassword("asd123");
        register.doClick();
        String result = register.checkMessage();
        assertTrue(result.contains("¡Cuenta registrada con éxito!"));

        System.out.println("Resultado obtenido: " + result);
    }

    @Test
    @Tag("Registros")
    public void testRegisterNegative() {
        home = new BasePage(driver);
        home.clickRegister();
        register = new RegisterPage(driver);
        register.enterName("John");
        register.enterLastname("Smith");
        register.enterEmail("johnsmith1@gmail.com");
        register.enterPassword("asd123");
        register.confirmPassword("asd123");
        register.doClick();
        String result = register.checkMessage2();
        assertTrue(result.contains("Ese email ya se encuentra registrado"));

        System.out.println("Resultado obtenido: " + result);
    }

    @AfterAll
    public void exit() {
        extent.flush();
        driver.quit();
    }
}
